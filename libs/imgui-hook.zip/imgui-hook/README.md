based off of work from aly in [GlueGD](https://github.com/s5bug/GlueGD)

imgui from https://github.com/ocornut/imgui
maybe i should make it a submodule